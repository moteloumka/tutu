package ch.epfl.tchu.game;

import javafx.scene.paint.Color;

public final class CheckJavaFx {
    public static void main(String[] args) {
        Color c = Color.RED;
        System.out.println(c.getRed());
    }
}
