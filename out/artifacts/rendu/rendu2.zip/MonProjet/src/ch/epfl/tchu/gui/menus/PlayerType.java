package ch.epfl.tchu.gui.menus;

public enum PlayerType {
    HOST,CLIENT;
}
