package ch.epfl.tchu.net;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public interface Serde <C> {

    abstract String serialize( C obj);
    abstract C deserialize(String cipher);

    static <T> Serde<T> of(Function<T, String> ser, Function<String, T> deSer){
        return new Serde<T>() {
            @Override
            public String serialize(T obj) {
                return ser.apply(obj);
            }

            @Override
            public T deserialize(String cipher) {
                return deSer.apply(cipher);
            }
        };
    }

    static <T> Serde<T> oneOf(List<T> enumList){
        Function<T,String> ser   = t -> String.valueOf(enumList.indexOf(t));
        Function<String,T> deSer = t -> enumList.get(Integer.parseInt(t));
        return Serde.of(ser,deSer);
    }

//    static <T> Serde<List<T>> listOf(Serde<T> serde, String str){
//        Function<Serde<T>,String> ser   = t -> serde.serialize(serde)+str;
//        Function<String,T> deSer = t -> enumList.get(Integer.parseInt(t));
//    }

}
