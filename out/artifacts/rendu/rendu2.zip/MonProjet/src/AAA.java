import javafx.scene.paint.Color;

final class CheckJavaFx {
    public static void main(String[] args) {
        Color c = Color.RED;
        System.out.println(c.getRed());
    }
}